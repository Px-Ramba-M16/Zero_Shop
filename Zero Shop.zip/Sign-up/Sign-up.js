const ham = document.getElementById("dehaze");
const menu = document.getElementById("menu");
const overlay = document.getElementById("overlay");
const closeMenu = document.getElementById("closeMenu"); // ปุ่มปิด

ham.addEventListener("click", () => {
        menu.classList.toggle("show");
        overlay.classList.toggle("show");
});

overlay.addEventListener("click", () => {
        menu.classList.remove("show");
        overlay.classList.remove("show");
});

closeMenu.addEventListener("click", () => {
        menu.classList.remove("show");
        overlay.classList.remove("show");
});

document.addEventListener("click", function(event) {
        if (!menu.contains(event.target) && !ham.contains(event.target)) {
                menu.classList.remove("show");
                overlay.classList.remove("show");
        }
});


const user = document.getElementById('user');
const email = document.getElementById('email');
const pass_1 = document.getElementById('pass_1');
const pass_2 = document.getElementById('pass_2');
const submit = document.getElementById('submit');
const form = document.querySelector('form');

// ดักการกด submit form
form.addEventListener('submit', function(e) {
        e.preventDefault(); // ป้องกันการ reload
        
        // ตรวจสอบว่าไม่มีช่องใดเว้นว่าง
        if (!user.value || !email.value || !pass_1.value || !pass_2.value) {
                alert('กรุณากรอกข้อมูลให้ครบทุกช่อง');
                return;
        }
        
        // ตรวจสอบความถูกต้องของอีเมล (เบื้องต้น)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email.value)) {
                alert('รูปแบบอีเมลไม่ถูกต้อง');
                return;
        }
        
        // ตรวจสอบรหัสผ่านตรงกัน
        if (pass_1.value !== pass_2.value) {
                alert('รหัสผ่านไม่ตรงกัน');
                return;
        }
        
        // ตรวจสอบความยาวรหัสผ่าน
        if (pass_1.value.length < 6) {
                alert('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
                return;
        }
        
        // ถ้าทุกอย่างผ่าน
        alert('สมัครสมาชิกสำเร็จ!');
        form.submit(); // ส่งฟอร์มไปยัง PHP
});

