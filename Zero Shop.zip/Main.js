const ham = document.getElementById("dehaze");
const menu = document.getElementById("menu");
const overlay = document.getElementById("overlay");
const closeMenu = document.getElementById("closeMenu"); // ปุ่มปิด

ham.addEventListener("click", () => {
        menu.classList.toggle("show");
        overlay.classList.toggle("show");
});

overlay.addEventListener("click", () => {
        menu.classList.remove("show");
        overlay.classList.remove("show");
});

closeMenu.addEventListener("click", () => {
        menu.classList.remove("show");
        overlay.classList.remove("show");
});

document.addEventListener("click", function(event) {
        if (!menu.contains(event.target) && !ham.contains(event.target)) {
                menu.classList.remove("show");
                overlay.classList.remove("show");
        }
});